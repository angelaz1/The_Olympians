[System.Serializable]
public class CharacterVars
{
    public string name;
    public string portraitPath;
    public string dialoguePath;
    public string postImagePath;
    public string backgroundPath;
    public int[] checkpointAffectionPts;
    public int[] checkpointFollowerCount;
    public int[] moveLimit;
    public int[] dateScoreReq;
}