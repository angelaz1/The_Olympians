﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ConverseButtonListener : ButtonListener
{
    public override void onClick() {
        GameObject.Find("InteractButtonManager").GetComponent<InteractButtonManager>().allFlyOff();
        // START DIALOGUE
        GameObject.Find("DialogueManager").GetComponent<DialogueManager>().startConversationDialogue();
    }
}
